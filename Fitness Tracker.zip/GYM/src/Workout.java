import javax.swing.ImageIcon;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JScrollPane; // Import for the scroll pane
import javax.swing.JTextArea;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.WindowConstants;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.ImageIcon;

import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;


public class Workout extends JFrame {
	

    public Workout() {
    	
    	try {
            UIManager.setLookAndFeel(new FlatLightLaf()); // Set the FlatLaf Look and Feel
        } catch (Exception e) {
            e.printStackTrace();
        }
    	JTextArea workoutDataTextArea;
        setSize(400, 400);
         // Set the background color of the JFrame
        setLayout(new GridLayout(6, 4));

        // Labels
        
        add(new JLabel("Workout"));
        add(new JLabel("Sets"));
        add(new JLabel("Reps"));
        setResizable(true);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        workoutDataTextArea = new JTextArea(10, 40);
        workoutDataTextArea.setEditable(false);
        String[] exerciseNames = {"Select Exercise", "Pullup", "Pushup", "Benchpress", "Deadlift", "Squat"};
        JComboBox exerciseDropdown = new JComboBox<>(exerciseNames);
        exerciseDropdown.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedExercise = (String) exerciseDropdown.getSelectedItem();
                if ("Select Exercise".equals(selectedExercise)) {
                    // Do nothing or show a message
                } else {
                    // Create a table name based on the selected exercise
                    String workout_data = selectedExercise.toLowerCase();
                    // You can then use this `tableName` in your database operations
                    // For example, you can use it in your SQL queries.
                    System.out.println("Selected exercise: " + selectedExercise);
                    System.out.println("Selected table name: " + workout_data);
                }
            }
        
        }
    );
        add(exerciseDropdown);}
        

    
    	
        
        
        
    
    public static Connection connectToDatabase() {
        Connection connection = null;
        try {
            String url = "jdbc:mysql://localhost:3306/gym";
            String username = "root";
            String password = "1234";
            connection = DriverManager.getConnection(url, username, password);

            // Create the table if it doesn't exist
            String createTableSQL = "CREATE TABLE IF NOT EXISTS workout_data ("+
                                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                                    "sets INT," +
                                    "reps INT," +
                                    "exercise VARCHAR(255)," +
                                    "timestamp TIMESTAMP" +
                                    ")";
            Statement statement = connection.createStatement();
            statement.execute(createTableSQL);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }
    
    
    public static void main(String[] args) throws Exception {
        // Get current date information
        Calendar cal = Calendar.getInstance();
        // Set format to month/day/year hours:minutes
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy HH:mm a");

        // Creates file object and sets pointer
        
        File file = new File("C:\\Users\\vishe\\Desktop\\workout trscker\\Workout Log.txt");
// File name + path
        // Ensures file exists and is not a directory
        if (!file.exists() || file.isDirectory()) {
            PrintWriter writer = new PrintWriter("Workout Log.txt", "UTF-8");
            writer.close();
        }

        // Write to file without overwriting current contents
        final PrintWriter output = new PrintWriter(new FileWriter(file, true));
        output.println("\n" + sdf.format(cal.getTime())); // Add date to file
        // Create Frame
        JFrame frame = new Workout();
        frame.setTitle("My Workout Tracker");
        
        

        // workout, set, and rep fields for data
        final JTextField[] workouts = {
            new JTextField("Push ups"),
            new JTextField("Dumbell Presses"),
            new JTextField("Dumbell Curls")
        };
        final JTextField[] sets = new JTextField[3];
        final JTextField[] reps = new JTextField[3];

        // add textfield pointers + add textfields to frame
        for (int i = 0; i < 3; i++) {
            frame.add(workouts[i]);
            sets[i] = new JTextField();
            frame.add(sets[i]);
            reps[i] = new JTextField();
            frame.add(reps[i]);
        }

        // Create checkboxes
        final JCheckBox abs = new JCheckBox("Abs?");
        final JCheckBox squat = new JCheckBox("Squats?");
        // Create Listener
        ActionListener checkListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == abs) {
                    if (abs.isSelected()) {
                        output.println("Ab Workout app used!");
                    }
                }
                else if (e.getSource() == squat) {
                    if (squat.isSelected()) {
                        output.println("Squat Workout app used!");
                    }
                }
            }
        };
        // Register listener with checkboxes
        abs.addActionListener(checkListener);
        squat.addActionListener(checkListener);
        // Add checkboxes to frame
        frame.add(abs);
        frame.add(squat);
        

            JButton log = new JButton("Log"); // To log everything
            // Register + create Event Listener
            log.addActionListener(new ActionListener() {
                
                public void actionPerformed(ActionEvent e) {
                    Connection connection = connectToDatabase();
                    

                    try {
                        for (int i = 0; i < 3; i++) {
                            if (sets[i].getText().length() > 0 && reps[i].getText().length() > 0) {
                                if (Integer.parseInt(sets[i].getText()) > 0 && Integer.parseInt(reps[i].getText()) > 0) {
                                    String insertSQL = "INSERT INTO workout_data (sets, reps, exercise) VALUES (?, ?, ?)";
                                    PreparedStatement preparedStatement = connection.prepareStatement(insertSQL);
                                    preparedStatement.setInt(1, Integer.parseInt(sets[i].getText()));
                                    preparedStatement.setInt(2, Integer.parseInt(reps[i].getText()));
                                    preparedStatement.setString(3, workouts[i].getText());
                                    preparedStatement.executeUpdate();
                                }
                            }
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    } finally {
                        try {
                            connection.close();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                    }
                    output.close();

                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException i) {
                        i.printStackTrace();
                    }
                    System.exit(0);
                }

				private Connection connectToDatabase() {
					// TODO Auto-generated method stub
					return null;
					
				}
            });

        
        frame.setSize(1000,800);
        frame.add(log);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
