import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

public class entries {
    private JComboBox<String> tableSelector;
    private JTextField setsField;
    private JTextField repsField;

    public entries() {
    	
        JFrame frame = new JFrame("SQL Data Entry");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(5, 2));

        // Table selector
        String[] tableNames = {"Pullups", "Pushups", "Benchpress", "Deadlift", "Squat"};
        tableSelector = new JComboBox<>(tableNames);
        frame.add(new JLabel("Select Exercise:"));
        frame.add(tableSelector);

        // Sets and Reps fields
        setsField = new JTextField(10);
        repsField = new JTextField(10);
        frame.add(new JLabel("Sets:"));
        frame.add(setsField);
        frame.add(new JLabel("Reps:"));
        frame.add(repsField);
        JButton graphButton = new JButton("Show Progress Graph");
        frame.add(graphButton);

        graphButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tableName = (String) tableSelector.getSelectedItem();
                showProgressGraph(tableName);
            }
        });


        // Submit button
        JButton submitButton = new JButton("Submit");
        frame.add(submitButton);

        // ActionListener for the submit button
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tableName = (String) tableSelector.getSelectedItem();
                int Sets = Integer.parseInt(setsField.getText());
                int Reps = Integer.parseInt(repsField.getText());

                // Insert data into the selected SQL table
                insertDataIntoTable(tableName, Sets, Reps);

                // Clear the input fields
                setsField.setText("");
                repsField.setText("");
            }
            
        });

        frame.pack();
        frame.setVisible(true);
    }
    private void showProgressGraph(String tableName) {
        // Create a dataset to store data for the progress graph
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        // Fetch data from the selected SQL table
        String jdbcURL = "jdbc:mysql://localhost:3306/gym";
        String username = "root";
        String password = "1234";

        try (Connection connection = DriverManager.getConnection(jdbcURL, username, password)) {
            String query = "SELECT sets, reps FROM " + tableName;
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int sets = resultSet.getInt("sets");
                int reps = resultSet.getInt("reps");
                // Add the data to the dataset
                dataset.addValue(sets, "Sets", "Entry " + dataset.getRowCount());
                dataset.addValue(reps, "Reps", "Entry " + dataset.getRowCount());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching data from " + tableName);
            return;
        }

        // Create a progress graph
        JFreeChart chart = ChartFactory.createLineChart(
            "Progress Chart for " + tableName,
            "Entry", "Value",
            dataset,
            PlotOrientation.VERTICAL,
            true, true, false);

        // Display the graph in a new frame
        JFrame graphFrame = new JFrame("Progress Graph");
        graphFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        ChartPanel chartPanel = new ChartPanel(chart);
        graphFrame.getContentPane().add(chartPanel);

        graphFrame.pack();
        graphFrame.setVisible(true);
    }

    // Method to insert data into the selected SQL table
    private void insertDataIntoTable(String tableName, int Sets, int Reps) {
        String jdbcURL = "jdbc:mysql://localhost:3306/gym";
        String username = "root";
        String password = "1234";

        try (Connection connection = DriverManager.getConnection(jdbcURL, username, password)) {
            String insertSQL = "INSERT INTO " + tableName + " (Sets, Reps) VALUES (?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertSQL);
            preparedStatement.setInt(1, Sets);
            preparedStatement.setInt(2, Reps);
            preparedStatement.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data inserted successfully into " + tableName);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error inserting data into " + tableName);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new entries ();
        });
    }
}
