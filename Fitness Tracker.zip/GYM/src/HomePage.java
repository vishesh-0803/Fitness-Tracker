import com.jgoodies.forms.builder.DefaultFormBuilder;

import com.jgoodies.forms.layout.FormLayout;

import javax.swing.*;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;

public class HomePage {
    public static void main(String[] args) {
    	try {
            UIManager.setLookAndFeel(new FlatDarkLaf()); // Set the FlatLaf Look and Feel
        } catch (Exception e) {
            e.printStackTrace();
        }
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Home Page");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

            FormLayout layout = new FormLayout(
                "center:pref:grow, 200px, center:pref:grow, 200px, center:pref:grow",
                "150px, pref, 150px, pref, 150px, pref, 150px"
            );

            DefaultFormBuilder builder = new DefaultFormBuilder(layout);
            builder.setDefaultDialogBorder();

            JButton bmiButton = new JButton("BMI");
            JButton exerciseButton = new JButton("Exercise");
            JButton exitButton = new JButton("Exit");

            bmiButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                	Gui_App guiApp = new Gui_App();
                    guiApp.main(null);
                    // Handle the BMI button action here
                }
            });

            exerciseButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                	entries entry = new entries();
                	try {
						entry.main(null);
						
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
                    // Handle the Exercise button action here
                	
                }
            });

            exitButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    System.exit(0);
                }
            });

            builder.append(bmiButton, 3);
            builder.nextLine();
            builder.append(exerciseButton, 3);
            builder.nextLine();
            builder.append(exitButton, 3);

            JPanel panel = builder.getPanel();
            frame.add(panel);

            frame.pack();
            frame.setLocationRelativeTo(null); // Center the frame
            frame.setVisible(true);
            frame.setSize(240,400);
        });
    }
}

