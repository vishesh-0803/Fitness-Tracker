import javax.imageio.ImageIO;
import javax.swing.*;
import java.text.DecimalFormat;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStream;
import org.pushingpixels.substance.api.skin.SubstanceRavenLookAndFeel;
import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;

public class Gui_App {
    public static void main(String[] args) {
    	try {
            UIManager.setLookAndFeel(new FlatDarkLaf()); // Set the FlatLaf Look and Feel
        } catch (Exception e) {
            e.printStackTrace();
        }
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("BMI Calculator");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(300, 300);
            frame.setLayout(new FlowLayout());

            JPanel backgroundPanel = new JPanel() {
                @Override
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    try {
                        InputStream inputStream = getClass().getResourceAsStream("/Fitness.jpeg");
                        if (inputStream != null) {
                            Image image = new ImageIcon(ImageIO.read(inputStream)).getImage();
                            g.drawImage(image, 0, 0, this);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            };
            backgroundPanel.setLayout(null);
            frame.add(backgroundPanel);

            JLabel exerciseLabel = new JLabel("Enter Gender: ");
            frame.add(exerciseLabel);

            JTextField exerciseField = new JTextField(20);
            frame.add(exerciseField);

            JLabel heightLabel = new JLabel("Enter your height (m): ");
            frame.add(heightLabel);

            JTextField heightField = new JTextField(20);
            frame.add(heightField);

            JLabel weightLabel = new JLabel("Enter your weight (kg): ");
            frame.add(weightLabel);

            JTextField weightField = new JTextField(20);
            frame.add(weightField);

            JButton submitButton = new JButton("Submit");
            frame.add(submitButton);

            submitButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        double enteredHeight = Double.parseDouble(heightField.getText());
                        double enteredWeight = Double.parseDouble(weightField.getText());
                        double BMI = enteredWeight / (enteredHeight * enteredHeight);
                        DecimalFormat dc = new DecimalFormat("0.00");
                        String formattedText = dc.format(BMI);
                        JOptionPane.showMessageDialog(frame, "The BMI: " + formattedText);
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(frame, "Please enter valid inputs");
                    }
                }
            });

            frame.setVisible(true);
        });
    }
}
