package submitButton;

public interface addActionListener {

}
